<?php
$con=mysqli_connect("localhost", "root", "", "eahpdb");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
$host = "localhost";
$username = "root";
$password = ""; // Default password for XAMPP's MySQL
$dbname = "eahpdb"; // Ensure this matches the database you created
}

  ?>
